import './App.css';
import Header from './component/Header';
import Footer from './component/Footer'
import {Route, Routes} from 'react-router-dom'
import SendParcel from './component/SendParcel';
import Tracking from './component/Tracking';
import Parcel from './component/Parcel';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle";
import Update from './component/Update';
import ConfirmCreate from './component/ConfirmationPage/ConfirmCreate';
import ConfirmDelete from './component/ConfirmationPage/ConfirmDelete';
import Home from './component/Home';
import Login from './component/UserAuth/Login';
import Registration from './component/UserAuth/Registration';


function App() {
  return (
    <div className="App">
      <Header/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/sendParcel' element={<SendParcel/>}/>
          <Route path='/parcel/:trackingNumber' element={<Parcel/>}/>
          <Route path='/tracking' element={<Tracking/>}/>
          <Route path='/update/:trackingNumber' element={<Update/>}/>
          <Route path='/confirmation/:id' element={<ConfirmCreate/>}/>
          <Route path='/deleted' element={<ConfirmDelete/>}/>
          <Route path='/home' element={<Home/>}/>
          <Route path='/login' element={<Login/>}/>
          <Route path='/register' element={<Registration/>}/>

        </Routes>
      <Footer/>
    </div>
  );
}

export default App;
