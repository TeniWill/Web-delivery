import '../styles/Footer.css'

const Footer = () => {
    
    
    return(
        <div className="footer">All rights reserved Package Management System 2023</div>
    )
    
    
}

export default Footer