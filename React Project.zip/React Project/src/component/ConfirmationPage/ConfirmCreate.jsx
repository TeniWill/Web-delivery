const ConfirmCreate = () => { 
    





    return (

        <div className='container p-3 my-3 border w-50 bg-light rounded'>
            <h1> Parcel successfully created </h1>

      

        </div>
    )
    
}

export default ConfirmCreate