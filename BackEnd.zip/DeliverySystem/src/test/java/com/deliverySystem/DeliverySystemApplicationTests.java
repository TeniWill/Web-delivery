package com.deliverySystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliverySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
